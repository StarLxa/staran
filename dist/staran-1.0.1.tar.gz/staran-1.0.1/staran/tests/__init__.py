#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Staran 测试包
============

包含完整的测试套件，用于验证所有功能的正确性。
"""

__all__ = []
